'use client';
import { useEffect, useState } from 'react';
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:3001';

export default function Documents() {
  const [data, setData] = useState<any>(null);
  const [type, setType] = useState('ID');
  const [err, setErr] = useState('');

  async function load() {
    const token = localStorage.getItem('accessToken') || '';
    const res = await fetch(`${API_BASE}/portal/dashboard`, { headers:{ Authorization:`Bearer ${token}` }});
    if(!res.ok) throw new Error(await res.text());
    setData(await res.json());
  }

  useEffect(()=>{ load().catch(e=>setErr(String(e.message||e))); }, []);

  if (err) return <div style={{ padding:24, color:'red' }}>{err}</div>;
  if (!data) return <div style={{ padding:24 }}>Loading...</div>;

  return (
    <div style={{ padding:24 }}>
      <h1>Documents</h1>

      <h3>Upload</h3>
      <select value={type} onChange={e=>setType(e.target.value)}>
        <option value="ID">ID</option>
        <option value="POA">Proof of Address</option>
        <option value="REPORT_PDF">Credit Report PDF</option>
        <option value="OTHER">Other</option>
      </select>
      <input id="file" type="file" />
      <button onClick={async ()=>{
        setErr('');
        try{
          const token = localStorage.getItem('accessToken') || '';
          const fileInput = document.getElementById('file') as HTMLInputElement;
          const file = fileInput.files?.[0];
          if(!file) throw new Error('Select a file');

          const form = new FormData();
          form.append('type', type);
          form.append('file', file);

          const res = await fetch(`${API_BASE}/clients/${data.clientId}/documents/upload`, {
            method:'POST',
            headers:{ Authorization:`Bearer ${token}` },
            body: form,
          });
          if(!res.ok) throw new Error(await res.text());
          await load();
        } catch(e:any){ setErr(e.message); }
      }}>Upload</button>

      {err && <p style={{ color:'red' }}>{err}</p>}

      <h3 style={{ marginTop:16 }}>My Files</h3>
      <ul>
        {data.docs.map((d:any)=>(
          <li key={d.id}>
            <b>{d.type}</b> — {d.filename} {' '}
            <button onClick={async ()=>{
              const token = localStorage.getItem('accessToken') || '';
              const r = await fetch(`${API_BASE}/portal/documents/${d.id}/download`, { headers:{ Authorization:`Bearer ${token}` }});
              if(!r.ok) return alert('Download failed');
              const j = await r.json();
              window.open(j.url, '_blank');
            }}>Download</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
