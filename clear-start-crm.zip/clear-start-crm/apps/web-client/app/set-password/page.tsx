'use client';
import { useSearchParams } from 'next/navigation';
import { useState } from 'react';
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:3001';

export default function SetPassword() {
  const params = useSearchParams();
  const token = params.get('token') || '';
  const [password, setPassword] = useState('');
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');

  return (
    <div style={{ padding:24 }}>
      <h1>Activate Portal</h1>
      <p>Set your password to activate your account.</p>
      <div style={{ display:'grid', gap: 8, maxWidth: 360 }}>
        <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="New password (min 8 chars)" />
        <button onClick={async ()=>{
          setErr(''); setMsg('');
          const res = await fetch(`${API_BASE}/auth/set-password`, {
            method:'POST',
            headers:{ 'Content-Type':'application/json' },
            body: JSON.stringify({ token, password })
          });
          if(!res.ok) return setErr('Invalid or expired link');
          setMsg('Password set! Now you can login.');
        }}>Set Password</button>
        {msg && <p style={{color:'green'}}>{msg}</p>}
        {err && <p style={{color:'red'}}>{err}</p>}
      </div>
    </div>
  );
}
