export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ fontFamily: 'Arial, sans-serif' }}>
        <div style={{ padding: 16, borderBottom: '1px solid #eee', display: 'flex', gap: 14 }}>
          <b>Clear Start Credit</b>
          <a href="/dashboard">Dashboard</a>
          <a href="/documents">Documents</a>
          <a href="/disputes">Disputes</a>
          <a href="/login">Login</a>
          <button
            style={{ marginLeft: 'auto' }}
            onClick={() => {
              if (typeof window !== 'undefined') {
                localStorage.removeItem('accessToken');
                window.location.href = '/login';
              }
            }}
          >
            Logout
          </button>
        </div>
        {children}
      </body>
    </html>
  );
}
