export default function Home() {
  return (
    <div style={{ padding: 24 }}>
      <h1>Clear Start Credit — Client Portal</h1>
      <p><a href="/login">Login</a></p>
    </div>
  );
}
