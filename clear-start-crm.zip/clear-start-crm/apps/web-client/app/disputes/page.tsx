'use client';
import { useEffect, useState } from 'react';
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:3001';

export default function Disputes() {
  const [data, setData] = useState<any>(null);
  const [err, setErr] = useState('');

  useEffect(()=>{ (async ()=>{
    try{
      const token = localStorage.getItem('accessToken') || '';
      if(!token) { window.location.href='/login'; return; }
      const res = await fetch(`${API_BASE}/portal/dashboard`, { headers:{ Authorization:`Bearer ${token}` }});
      if(!res.ok) throw new Error(await res.text());
      setData(await res.json());
    } catch(e:any){ setErr(e.message); }
  })(); }, []);

  if (err) return <div style={{ padding:24, color:'red' }}>{err}</div>;
  if (!data) return <div style={{ padding:24 }}>Loading...</div>;

  return (
    <div style={{ padding:24 }}>
      <h1>Disputes</h1>
      {data.disputes.length===0 ? <p>No disputes yet.</p> : (
        <ul>
          {data.disputes.map((d:any)=>(
            <li key={d.id} style={{ marginBottom: 12 }}>
              <b>{d.bureau}</b> — Round {d.round} — {d.status}<br/>
              Items: {d.items.length} — Letters: {d.letters.length}
              <div style={{ marginTop: 6 }}>
                {d.letters.map((L:any)=>(
                  <button key={L.id} style={{ marginRight: 8 }} onClick={async ()=>{
                    const token = localStorage.getItem('accessToken') || '';
                    const r = await fetch(`${API_BASE}/portal/letters/${L.id}/download`, { headers:{ Authorization:`Bearer ${token}` }});
                    if(!r.ok) return alert('Download failed');
                    const j = await r.json();
                    window.open(j.url, '_blank');
                  }}>
                    Download Letter ({new Date(L.createdAt).toLocaleDateString()})
                  </button>
                ))}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
