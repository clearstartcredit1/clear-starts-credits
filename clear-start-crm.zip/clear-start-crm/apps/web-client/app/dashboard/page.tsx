'use client';
import { useEffect, useState } from 'react';
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:3001';

export default function Dashboard() {
  const [dash, setDash] = useState<any>(null);
  const [prog, setProg] = useState<any>(null);
  const [err, setErr] = useState('');

  useEffect(()=>{ (async ()=>{
    try{
      const token = localStorage.getItem('accessToken') || '';
      if(!token) { window.location.href='/login'; return; }

      const a = await fetch(`${API_BASE}/portal/dashboard`, { headers:{ Authorization:`Bearer ${token}` }});
      const b = await fetch(`${API_BASE}/portal/progress`, { headers:{ Authorization:`Bearer ${token}` }});
      if(!a.ok) throw new Error(await a.text());
      if(!b.ok) throw new Error(await b.text());
      setDash(await a.json());
      setProg(await b.json());
    } catch(e:any){ setErr(e.message); }
  })(); }, []);

  if (err) return <div style={{ padding:24, color:'red' }}>{err}</div>;
  if (!dash || !prog) return <div style={{ padding:24 }}>Loading...</div>;

  return (
    <div style={{ padding:24 }}>
      <h1>My Dashboard</h1>

      <h3>Progress</h3>
      <div style={{ border:'1px solid #eee', borderRadius:10, padding:12, maxWidth: 520 }}>
        <div style={{ background:'#eee', borderRadius:8, height:14, overflow:'hidden' }}>
          <div style={{ width: `${prog.percent}%`, height: 14, background:'#111' }} />
        </div>
        <p><b>{prog.percent}%</b> complete</p>
        {prog.nextSteps?.length ? (
          <>
            <b>Next steps:</b>
            <ul>{prog.nextSteps.map((s:string, i:number)=><li key={i}>{s}</li>)}</ul>
          </>
        ) : <p>Everything is up to date.</p>}
      </div>

      <h3 style={{ marginTop:16 }}>Latest Activity</h3>
      <p><b>Disputes:</b> {dash.disputes.length}</p>
      <p><b>Documents:</b> {dash.docs.length}</p>
    </div>
  );
}
