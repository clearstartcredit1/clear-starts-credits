'use client';
import { useState } from 'react';
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:3001';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');

  return (
    <div style={{ padding:24 }}>
      <h1>Client Login</h1>
      <div style={{ display:'grid', gap: 8, maxWidth: 360 }}>
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="email" />
        <input value={password} onChange={e=>setPassword(e.target.value)} placeholder="password" type="password" />
        <button onClick={async ()=>{
          setErr('');
          const res = await fetch(`${API_BASE}/auth/login`, {
            method:'POST',
            headers:{ 'Content-Type':'application/json' },
            body: JSON.stringify({ email, password })
          });
          if(!res.ok) return setErr('Login failed');
          const j = await res.json();
          localStorage.setItem('accessToken', j.accessToken);
          window.location.href = '/dashboard';
        }}>Login</button>
        {err && <p style={{color:'red'}}>{err}</p>}
      </div>
    </div>
  );
}
