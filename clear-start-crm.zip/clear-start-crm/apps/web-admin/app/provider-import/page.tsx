'use client';
import { useState } from 'react';
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:3001';

export default function ProviderImport() {
  const [clientId, setClientId] = useState('');
  const [provider, setProvider] = useState('PROVIDER_A');
  const [json, setJson] = useState('{"tradelines":[{"furnisher":"Capital One","type":"Revolving","status":"Open","bureau":"EX","balance":900,"limit":1000}]}');
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');

  return (
    <div style={{ padding:24 }}>
      <h1>Provider Import (Manual)</h1>
      <div style={{ display:'flex', gap: 10 }}>
        <input style={{ width: 360 }} placeholder="Client ID" value={clientId} onChange={e=>setClientId(e.target.value)} />
        <select value={provider} onChange={e=>setProvider(e.target.value)}>
          <option value="PROVIDER_A">PROVIDER_A</option>
        </select>
      </div>

      <p>Paste payload JSON:</p>
      <textarea rows={14} style={{ width:'100%', fontFamily:'monospace' }} value={json} onChange={e=>setJson(e.target.value)} />

      <button onClick={async ()=>{
        setErr(''); setMsg('');
        try{
          const token = localStorage.getItem('accessToken') || '';
          const res = await fetch(`${API_BASE}/provider-import`, {
            method:'POST',
            headers:{ 'Content-Type':'application/json', Authorization:`Bearer ${token}` },
            body: JSON.stringify({ clientId, provider, json })
          });
          if(!res.ok) throw new Error(await res.text());
          const j = await res.json();
          setMsg(`Enqueued job ${j.jobId}. Automation runs hourly (or restart API to trigger sooner).`);
        } catch(e:any){ setErr(e.message); }
      }}>Enqueue Import</button>

      {msg && <p style={{ color:'green' }}>{msg}</p>}
      {err && <p style={{ color:'red' }}>{err}</p>}
    </div>
  );
}
