'use client';
import { useEffect, useState } from 'react';
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:3001';

export default function Snapshot({ params }: any) {
  const snapshotId = params.snapshotId as string;
  const [tradelines, setTradelines] = useState<any[]>([]);
  const [findings, setFindings] = useState<any[]>([]);
  const [clientId, setClientId] = useState('');
  const [err, setErr] = useState('');

  const [furnisher, setFurnisher] = useState('');
  const [accountType, setAccountType] = useState('Revolving');
  const [status, setStatus] = useState('Open');
  const [bureau, setBureau] = useState('EX');

  async function load() {
    const token = localStorage.getItem('accessToken') || '';
    const s = await fetch(`${API_BASE}/reports/snapshot/${snapshotId}`, { headers: { Authorization: `Bearer ${token}` } });
    const snap = await s.json();
    setClientId(snap.clientId);

    const tl = await fetch(`${API_BASE}/reports/${snapshotId}/tradelines`, { headers: { Authorization: `Bearer ${token}` }});
    setTradelines(await tl.json());

    const fi = await fetch(`${API_BASE}/reports/${snapshotId}/findings`, { headers: { Authorization: `Bearer ${token}` }});
    const j = await fi.json();
    setFindings(j.findings || []);
  }

  useEffect(()=>{ load().catch(e=>setErr(String(e.message||e))); }, []);

  return (
    <div style={{ padding:24 }}>
      <h1>Snapshot</h1>
      <p><a href={`/clients/${clientId}/reports`}>← Back to snapshots</a></p>
      {err && <p style={{color:'red'}}>{err}</p>}

      <h2>Tradelines</h2>
      <div style={{ border:'1px solid #eee', padding:12, borderRadius:10, maxWidth: 640 }}>
        <input placeholder="Furnisher" value={furnisher} onChange={e=>setFurnisher(e.target.value)} />
        <input placeholder="Account Type" value={accountType} onChange={e=>setAccountType(e.target.value)} />
        <input placeholder="Status" value={status} onChange={e=>setStatus(e.target.value)} />
        <select value={bureau} onChange={e=>setBureau(e.target.value)}>
          <option value="EX">EX</option><option value="EQ">EQ</option><option value="TU">TU</option>
        </select>
        <button onClick={async ()=>{
          try{
            const token = localStorage.getItem('accessToken') || '';
            const res = await fetch(`${API_BASE}/reports/${snapshotId}/tradelines`, {
              method:'POST',
              headers:{ 'Content-Type':'application/json', Authorization:`Bearer ${token}` },
              body: JSON.stringify({ furnisher, accountType, status, bureau })
            });
            if(!res.ok) throw new Error(await res.text());
            setFurnisher('');
            await load();
          } catch(e:any){ setErr(e.message); }
        }}>Add</button>
      </div>

      <ul>
        {tradelines.map(t=>(
          <li key={t.id}><b>{t.furnisher}</b> — {t.accountType} — {t.status} — {t.bureau || '-'}</li>
        ))}
      </ul>

      <h2>Audit</h2>
      <button onClick={async ()=>{
        try{
          const token = localStorage.getItem('accessToken') || '';
          const res = await fetch(`${API_BASE}/reports/${snapshotId}/audit`, { method:'POST', headers:{ Authorization:`Bearer ${token}` }});
          if(!res.ok) throw new Error(await res.text());
          await load();
        } catch(e:any){ setErr(e.message); }
      }}>Run Audit</button>

      <h3>Findings</h3>
      {findings.length===0 ? <p>No findings</p> : (
        <ul>
          {findings.map((f:any)=>(
            <li key={f.id}><b>[S{f.severity}] {f.title}</b> — {f.description}</li>
          ))}
        </ul>
      )}
      <p><a href={`/wizard/${snapshotId}`}>Open Wizard →</a></p>
    </div>
  );
}
