'use client';
import { useEffect, useState } from 'react';
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:3001';

export default function Tasks() {
  const [rows, setRows] = useState<any[]>([]);
  const [err, setErr] = useState('');

  async function load() {
    const token = localStorage.getItem('accessToken') || '';
    const res = await fetch(`${API_BASE}/tasks/open`, { headers:{ Authorization:`Bearer ${token}` }});
    if(!res.ok) throw new Error(await res.text());
    setRows(await res.json());
  }

  useEffect(()=>{ load().catch(e=>setErr(String(e.message||e))); }, []);

  return (
    <div style={{ padding:24 }}>
      <h1>Tasks</h1>
      {err && <p style={{color:'red'}}>{err}</p>}
      <ul>
        {rows.map(t=>(
          <li key={t.id}>
            <b>{t.title}</b> — {t.type} — due {t.dueAt ? new Date(t.dueAt).toLocaleString() : 'n/a'} {' '}
            <a href={`/clients/${t.clientId}`}>Open Client</a>{' '}
            <button onClick={async ()=>{
              const token = localStorage.getItem('accessToken') || '';
              await fetch(`${API_BASE}/tasks/${t.id}/done`, { method:'PATCH', headers:{ Authorization:`Bearer ${token}` }});
              await load();
            }}>Done</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
