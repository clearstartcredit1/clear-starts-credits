'use client';
import { useEffect, useMemo, useState } from 'react';
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:3001';

export default function Wizard({ params }: any) {
  const snapshotId = params.snapshotId as string;
  const [data, setData] = useState<any>(null);
  const [selected, setSelected] = useState<Record<string, boolean>>({});
  const [bureau, setBureau] = useState('EX');
  const [round, setRound] = useState(1);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  async function load() {
    const token = localStorage.getItem('accessToken') || '';
    const res = await fetch(`${API_BASE}/wizard/snapshot/${snapshotId}`, { headers: { Authorization: `Bearer ${token}` }});
    if(!res.ok) throw new Error(await res.text());
    setData(await res.json());
  }

  useEffect(()=>{ load().catch(e=>setErr(String(e.message||e))); }, []);

  const findings = data?.latestAudit?.findings || [];
  const chosen = useMemo(() => Object.keys(selected).filter(id => selected[id]), [selected]);

  if (!data) return <div style={{ padding:24 }}>{err ? <span style={{color:'red'}}>{err}</span> : 'Loading...'}</div>;

  const client = data.snapshot.client;

  return (
    <div style={{ padding:24 }}>
      <h1>Dispute Wizard</h1>
      <div style={{ padding:12, border:'1px solid #eee', borderRadius:10, marginBottom:16 }}>
        <b>Client:</b> {client.firstName} {client.lastName} — {client.email || ''}
        <br/>
        <b>Snapshot:</b> {new Date(data.snapshot.pulledAt).toLocaleString()} ({data.snapshot.provider})
      </div>

      {err && <p style={{ color:'red' }}>{err}</p>}

      <h2>Step 1 — Run Audit</h2>
      <button disabled={busy} onClick={async ()=>{
        setBusy(true); setErr('');
        try{
          const token = localStorage.getItem('accessToken') || '';
          const r = await fetch(`${API_BASE}/reports/${snapshotId}/audit`, { method:'POST', headers:{ Authorization:`Bearer ${token}` }});
          if(!r.ok) throw new Error(await r.text());
          await load();
        } catch(e:any){ setErr(e.message); }
        finally{ setBusy(false); }
      }}>Run Audit Now</button>

      <h2 style={{ marginTop:18 }}>Step 2 — Select Findings</h2>
      {findings.length===0 ? <p>No findings yet.</p> : (
        <ul>
          {findings.map((f:any)=>(
            <li key={f.id}>
              <label>
                <input type="checkbox" checked={!!selected[f.id]} onChange={(e)=>setSelected(prev=>({ ...prev, [f.id]: e.target.checked }))} />
                {' '}<b>[S{f.severity}] {f.title}</b> — {f.description}
              </label>
            </li>
          ))}
        </ul>
      )}

      <h2 style={{ marginTop:18 }}>Step 3 — Create Dispute</h2>
      <div style={{ display:'flex', gap: 10, alignItems:'center' }}>
        <label>Bureau:</label>
        <select value={bureau} onChange={e=>setBureau(e.target.value)}>
          <option value="EX">EX</option><option value="EQ">EQ</option><option value="TU">TU</option>
        </select>
        <label>Round:</label>
        <select value={round} onChange={e=>setRound(Number(e.target.value))}>
          <option value={1}>1</option><option value={2}>2</option><option value={3}>3</option>
        </select>
      </div>

      <button disabled={busy || chosen.length===0} onClick={async ()=>{
        setBusy(true); setErr('');
        try{
          const token = localStorage.getItem('accessToken') || '';
          const r = await fetch(`${API_BASE}/disputes`, {
            method:'POST',
            headers:{ 'Content-Type':'application/json', Authorization:`Bearer ${token}` },
            body: JSON.stringify({ clientId: data.snapshot.clientId, bureau, round, findingIds: chosen })
          });
          if(!r.ok) throw new Error(await r.text());
          await load();
          alert('Dispute created');
        } catch(e:any){ setErr(e.message); }
        finally{ setBusy(false); }
      }}>Create Dispute</button>

      <h2 style={{ marginTop:18 }}>Step 4 — Generate Letter + Mark Sent</h2>
      <ul>
        {data.disputes.map((d:any)=>(
          <li key={d.id} style={{ marginBottom: 12 }}>
            <b>{d.bureau}</b> — Round {d.round} — {d.status} — Items {d.items.length} — Letters {d.letters.length}
            <div style={{ marginTop: 6 }}>
              <button disabled={busy} onClick={async ()=>{
                setBusy(true); setErr('');
                try{
                  const token = localStorage.getItem('accessToken') || '';
                  const r = await fetch(`${API_BASE}/letters/${d.id}/generate`, { method:'POST', headers:{ Authorization:`Bearer ${token}` }});
                  if(!r.ok) throw new Error(await r.text());
                  await load();
                  alert('Letter generated');
                } catch(e:any){ setErr(e.message); }
                finally{ setBusy(false); }
              }}>Generate Letter</button>

              <button disabled={busy} style={{ marginLeft: 8 }} onClick={async ()=>{
                const latest = d.letters?.[0];
                if(!latest) return alert('No letters yet');
                const token = localStorage.getItem('accessToken') || '';
                const r = await fetch(`${API_BASE}/letters/${latest.id}/download`, { headers:{ Authorization:`Bearer ${token}` }});
                if(!r.ok) return alert('Download failed');
                const j = await r.json();
                window.open(j.url, '_blank');
              }}>Download Latest</button>

              <button disabled={busy} style={{ marginLeft: 8 }} onClick={async ()=>{
                setBusy(true); setErr('');
                try{
                  const token = localStorage.getItem('accessToken') || '';
                  const r = await fetch(`${API_BASE}/disputes/${d.id}`, {
                    method:'PATCH',
                    headers:{ 'Content-Type':'application/json', Authorization:`Bearer ${token}` },
                    body: JSON.stringify({ status: 'SENT' })
                  });
                  if(!r.ok) throw new Error(await r.text());
                  await load();
                  alert('Marked SENT (follow-up task + reminders will trigger)');
                } catch(e:any){ setErr(e.message); }
                finally{ setBusy(false); }
              }}>Mark SENT</button>
            </div>
          </li>
        ))}
      </ul>

      {err && <p style={{ color:'red' }}>{err}</p>}
    </div>
  );
}
