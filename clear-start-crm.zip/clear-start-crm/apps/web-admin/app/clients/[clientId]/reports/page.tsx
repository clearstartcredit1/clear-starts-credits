'use client';
import { useEffect, useState } from 'react';

const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:3001';

export default function Reports({ params }: any) {
  const clientId = params.clientId as string;
  const [rows, setRows] = useState<any[]>([]);
  const [err, setErr] = useState('');

  async function load() {
    const token = localStorage.getItem('accessToken') || '';
    const res = await fetch(`${API_BASE}/reports/client/${clientId}`, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) throw new Error(await res.text());
    setRows(await res.json());
  }

  useEffect(() => { load().catch(e=>setErr(String(e.message||e))); }, []);

  return (
    <div style={{ padding:24 }}>
      <h1>Snapshots</h1>
      <p><a href={`/clients/${clientId}`}>← Client Hub</a></p>

      <button onClick={async ()=>{
        setErr('');
        try {
          const token = localStorage.getItem('accessToken') || '';
          const res = await fetch(`${API_BASE}/reports/snapshots`, {
            method:'POST',
            headers: { 'Content-Type':'application/json', Authorization:`Bearer ${token}`},
            body: JSON.stringify({ clientId, provider:'MANUAL', reportType:'TRIMERGE' })
          });
          if(!res.ok) throw new Error(await res.text());
          await load();
        } catch(e:any){ setErr(e.message); }
      }}>+ New Snapshot</button>

      {err && <p style={{color:'red'}}>{err}</p>}

      <ul style={{ marginTop: 16 }}>
        {rows.map(s=>(
          <li key={s.id}>
            {new Date(s.pulledAt).toLocaleString()} — {s.provider} — <a href={`/reports/${s.id}`}>Open</a>
            <a href={`/wizard/${s.id}`} style={{ marginLeft: 10 }}>Wizard</a>
          </li>
        ))}
      </ul>
    </div>
  );
}
