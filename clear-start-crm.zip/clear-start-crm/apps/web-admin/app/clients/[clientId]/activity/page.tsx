'use client';
import { useEffect, useState } from 'react';
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:3001';

export default function ClientActivity({ params }: any) {
  const clientId = params.clientId as string;
  const [rows, setRows] = useState<any[]>([]);
  const [err, setErr] = useState('');

  useEffect(()=>{ (async ()=>{
    try{
      const token = localStorage.getItem('accessToken') || '';
      const res = await fetch(`${API_BASE}/activity/client/${clientId}`, { headers:{ Authorization:`Bearer ${token}` }});
      if(!res.ok) throw new Error(await res.text());
      setRows(await res.json());
    } catch(e:any){ setErr(e.message); }
  })(); }, [clientId]);

  return (
    <div style={{ padding:24 }}>
      <h1>Client Activity</h1>
      <p><a href={`/clients/${clientId}`}>← Client Hub</a></p>
      {err && <p style={{color:'red'}}>{err}</p>}
      <ul>
        {rows.map(a=>(
          <li key={a.id}><b>{a.action}</b> — {a.detail || ''} — {new Date(a.createdAt).toLocaleString()}</li>
        ))}
      </ul>
    </div>
  );
}
