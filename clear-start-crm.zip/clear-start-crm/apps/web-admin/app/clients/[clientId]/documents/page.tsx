'use client';
import { useEffect, useState } from 'react';
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:3001';

export default function AdminDocs({ params }: any) {
  const clientId = params.clientId as string;
  const [docs, setDocs] = useState<any[]>([]);
  const [err, setErr] = useState('');

  async function load() {
    const token = localStorage.getItem('accessToken') || '';
    const res = await fetch(`${API_BASE}/clients/${clientId}/documents`, { headers:{ Authorization:`Bearer ${token}` }});
    if(!res.ok) throw new Error(await res.text());
    setDocs(await res.json());
  }

  useEffect(()=>{ load().catch(e=>setErr(String(e.message||e))); }, []);

  return (
    <div style={{ padding:24 }}>
      <h1>Documents</h1>
      <p><a href={`/clients/${clientId}`}>← Client Hub</a></p>
      {err && <p style={{color:'red'}}>{err}</p>}

      <ul>
        {docs.map(d=>(
          <li key={d.id}>
            <b>{d.type}</b> — {d.filename}
            {' '}<button onClick={async ()=>{
              const token = localStorage.getItem('accessToken') || '';
              const r = await fetch(`${API_BASE}/clients/${clientId}/documents/${d.id}/download`, { headers:{ Authorization:`Bearer ${token}` }});
              if(!r.ok) return alert('download failed');
              const j = await r.json();
              window.open(j.url, '_blank');
            }}>Download</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
