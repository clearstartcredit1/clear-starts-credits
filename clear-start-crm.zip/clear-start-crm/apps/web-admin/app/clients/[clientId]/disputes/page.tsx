'use client';
import { useEffect, useState } from 'react';
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:3001';

export default function Disputes({ params }: any) {
  const clientId = params.clientId as string;
  const [rows, setRows] = useState<any[]>([]);
  const [err, setErr] = useState('');

  async function load() {
    const token = localStorage.getItem('accessToken') || '';
    const res = await fetch(`${API_BASE}/disputes/client/${clientId}`, { headers:{ Authorization:`Bearer ${token}` }});
    if(!res.ok) throw new Error(await res.text());
    setRows(await res.json());
  }

  useEffect(()=>{ load().catch(e=>setErr(String(e.message||e))); }, []);

  return (
    <div style={{ padding:24 }}>
      <h1>Disputes</h1>
      <p><a href={`/clients/${clientId}`}>← Client Hub</a></p>
      {err && <p style={{color:'red'}}>{err}</p>}
      <ul>
        {rows.map(d=>(
          <li key={d.id}>
            <b>{d.bureau}</b> — Round {d.round} — {d.status} — Items {d.items.length} — Letters {d.letters.length}
          </li>
        ))}
      </ul>
    </div>
  );
}
