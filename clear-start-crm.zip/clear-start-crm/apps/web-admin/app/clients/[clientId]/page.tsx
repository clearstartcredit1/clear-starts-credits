'use client';
export default function ClientHub({ params }: any) {
  const clientId = params.clientId as string;
  return (
    <div style={{ padding: 24 }}>
      <h1>Client Hub</h1>
      <p><b>Client ID:</b> {clientId}</p>
      <ul>
        <li><a href={`/clients/${clientId}/reports`}>Reports & Audits</a></li>
        <li><a href={`/clients/${clientId}/disputes`}>Disputes & Letters</a></li>
        <li><a href={`/clients/${clientId}/documents`}>Documents</a></li>
        <li><a href={`/clients/${clientId}/activity`}>Activity</a></li>
      </ul>
      <p><a href="/clients">← Back</a></p>
    </div>
  );
}
