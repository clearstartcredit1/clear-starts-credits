'use client';
import { useEffect, useState } from 'react';

const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:3001';

export default function Clients() {
  const [rows, setRows] = useState<any[]>([]);
  const [err, setErr] = useState('');

  const [firstName, setFirstName] = useState('John');
  const [lastName, setLastName] = useState('Doe');
  const [email, setEmail] = useState('client1@example.com');

  async function load() {
    const token = localStorage.getItem('accessToken') || '';
    const res = await fetch(`${API_BASE}/clients`, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) throw new Error(await res.text());
    setRows(await res.json());
  }

  useEffect(() => {
    if (!localStorage.getItem('accessToken')) window.location.href = '/login';
    load().catch((e) => setErr(String(e.message || e)));
  }, []);

  return (
    <div style={{ padding: 24 }}>
      <h1>Clients</h1>

      <div style={{ border: '1px solid #eee', padding: 12, borderRadius: 10, maxWidth: 520 }}>
        <b>Create client + portal invite</b>
        <div style={{ display: 'grid', gap: 8, marginTop: 8 }}>
          <input value={firstName} onChange={(e) => setFirstName(e.target.value)} placeholder="First name" />
          <input value={lastName} onChange={(e) => setLastName(e.target.value)} placeholder="Last name" />
          <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email (for invite)" />
          <button
            onClick={async () => {
              setErr('');
              try {
                const token = localStorage.getItem('accessToken') || '';
                const res = await fetch(`${API_BASE}/clients`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
                  body: JSON.stringify({ firstName, lastName, email, createPortalUser: true }),
                });
                if (!res.ok) throw new Error(await res.text());
                await load();
                alert('Client created + invite emailed (check MailHog)');
              } catch (e: any) {
                setErr(e.message);
              }
            }}
          >
            Create + Invite
          </button>
        </div>
      </div>

      {err && <p style={{ color: 'red' }}>{err}</p>}

      <ul style={{ marginTop: 16 }}>
        {rows.map((c) => (
          <li key={c.id} style={{ marginBottom: 6 }}>
            <b>
              {c.firstName} {c.lastName}
            </b>{' '}
            — {c.email || 'no email'} — <a href={`/clients/${c.id}`}>Open</a>
          </li>
        ))}
      </ul>
    </div>
  );
}
