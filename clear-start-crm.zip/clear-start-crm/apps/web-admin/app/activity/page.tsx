'use client';
import { useEffect, useState } from 'react';
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:3001';

export default function Activity() {
  const [rows, setRows] = useState<any[]>([]);
  const [err, setErr] = useState('');

  useEffect(()=>{ (async ()=>{
    try{
      const token = localStorage.getItem('accessToken') || '';
      const res = await fetch(`${API_BASE}/activity/recent`, { headers:{ Authorization:`Bearer ${token}` }});
      if(!res.ok) throw new Error(await res.text());
      setRows(await res.json());
    } catch(e:any){ setErr(e.message); }
  })(); }, []);

  return (
    <div style={{ padding:24 }}>
      <h1>Activity</h1>
      {err && <p style={{color:'red'}}>{err}</p>}
      <ul>
        {rows.map(a=>(
          <li key={a.id}>
            <b>{a.action}</b> — {a.clientId ? <a href={`/clients/${a.clientId}`}>{a.clientId}</a> : '—'} — {a.detail || ''} — {new Date(a.createdAt).toLocaleString()}
          </li>
        ))}
      </ul>
    </div>
  );
}
